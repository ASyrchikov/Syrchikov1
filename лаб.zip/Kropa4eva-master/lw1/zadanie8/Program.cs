﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie8
{
    class Program
    {
        static void Main(string[] args)
        {
            string A;
            A = Console.ReadLine();
            int a;
            a = int.Parse(A);
            Console.WriteLine("\""+ a +"\"");
            Console.WriteLine("\"{0}\"",a);
        }
    }
}
