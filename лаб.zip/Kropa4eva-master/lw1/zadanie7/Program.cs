﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie7
{
    class Program
    {
        static void Main(string[] args)
        {
            String A;
            A = Console.ReadLine();
            double a;
            a = double.Parse(A);
            Console.WriteLine("{0:F4}",a);


        }
    }
}
