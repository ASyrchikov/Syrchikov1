﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Yra, zarabotalo!\\ 123");
            Console.WriteLine();
            Console.WriteLine("+---+\n|   |\n|   |\n+---+");
            Console.WriteLine();
            Console.WriteLine("#\n##\n###\n####");
            Console.WriteLine();
            Console.WriteLine(" /\\\n//\\\\\n//\\\\\n ][ ");
            Console.WriteLine();
            Console.WriteLine("{ \"x\":15, \"y\":28.7}");
            Console.WriteLine();
            Console.WriteLine("Три девицы под окном\nПряли поздно вечерком.\n\"Кабы я была царицаб -\nГоворит одна девица, -\nТо на весь крещеный мир\nПриготовила б я пир\".\n\"Кабы я была царица, -\nГоворит ее сестрица, -\nТо на весь бы мир одна\nНаткала я полотна\".\n\"Кабы я была царица, -\nТретья молвила сестрица, -\nЯ б для батюшки-царя\nРодила богатыря\".");
            Console.WriteLine();
            Console.WriteLine("<!DOCTYPE html>\n<html>\n<head>\n    <meta charset=\"utf-8\"/>\n<head/>\n<body>\n    <h1>Мой первый векторный рисунок</h1>\n\n<svg width=\"800\" height=\"600\">\n      <circle cx\"50\" cy=\"50\" r=\"40\" stroke=\"green\"\n              stroke-width=\"4\" fill=\"yellow\"/>\n    </svg>\n</body>\n</html> ");
        }
    }
}
