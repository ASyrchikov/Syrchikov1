﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zna4inie Pi: {0:F4}\n Zna4enie e: {1:F4}", Math.PI, Math.E);
        }
    }
}
