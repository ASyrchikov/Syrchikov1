﻿using lab14;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab14
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(8403);
            Caller8403.Step1();
            Caller8403.Step2();
            Caller8403.Step3();
            Caller8403.Step4();
            Console.WriteLine();

            Console.WriteLine(3185);
            Caller3185.Step1();
            Caller3185.Step2();
            Caller3185.Step3();
            Caller3185.Step4();
            Caller3185.Step5();
            Console.WriteLine();

            Console.WriteLine(9914);
            Caller9914.Step1();
            Caller9914.Step2();
            Caller9914.Step3();
            Caller9914.Step4();
            Caller9914.Step5();
            Caller9914.Step6();
            Caller9914.Step7();
            Console.WriteLine();

            Console.WriteLine(6011);
            Caller6011.Step1();
            Caller6011.Step2();
            Caller6011.Step3();
            Caller6011.Step4();
            Caller6011.Step5();
            Console.WriteLine();

            Console.WriteLine(6037);
            Caller6037.Step1();
            Caller6037.Step2();
            Caller6037.Step3();
            Caller6037.Step4();
            Console.WriteLine();

            Console.WriteLine(2809);
            Caller2809.Step1();
            Caller2809.Step2();
            Caller2809.Step3();
            Caller2809.Step4();
            Caller2809.Step5();
            Console.WriteLine();

            Console.WriteLine(7297);
            Caller7297.Step1();
            Caller7297.Step2();
            Caller7297.Step3();
            Caller7297.Step4();
            Console.WriteLine();

            Console.WriteLine(5242);
            Caller5242.Step1();
            Caller5242.Step2();
            Console.WriteLine();

            Console.WriteLine(1379);
            Caller1379.Step1();
            Caller1379.Step2();
            Caller1379.Step3();
            Caller1379.Step4();
            Console.WriteLine();

            Console.WriteLine(2401);
            Caller2401.Step1();
            Caller2401.Step2();
            Caller2401.Step3();
            Caller2401.Step4();
            Console.WriteLine();

            Console.WriteLine(5421);
            Caller5421.Step1();
            Caller5421.Step2();
            Caller5421.Step3();
            Caller5421.Step4();
            Console.WriteLine();

            Console.WriteLine(9713);
            Caller9713.Step1();
            Caller9713.Step2();
            Caller9713.Step3();
            Caller9713.Step4();
            Console.WriteLine();

            Console.WriteLine(7301);
            Caller7301.Step1();
            Caller7301.Step2();
            Caller7301.Step3();
            Caller7301.Step4();
            Caller7301.Step5();
            Caller7301.Step6();
            Caller7301.Step7();
            Console.WriteLine();

            Console.WriteLine(2000);
            Caller2000.Step1();
            Caller2000.Step2();
            Caller2000.Step3();
            Caller2000.Step4();
            Caller2000.Step5();
            Caller2000.Step6();
            Caller2000.Step7();
            Console.WriteLine();

            Console.WriteLine(5449);
            Caller5449.Step1();
            Caller5449.Step2();
            Caller5449.Step3();
            Caller5449.Step4();
            Caller5449.Step5();
            Caller5449.Step6();
            Console.WriteLine();

            Console.WriteLine(2662);
            Caller2662.Step1();
            Caller2662.Step2();
            Caller2662.Step3();
            Caller2662.Step4();
            Caller2662.Step5();
            Caller2662.Step6();
            Console.WriteLine();

            Console.WriteLine(4147);
            Caller4147.Step1();
            Caller4147.Step2();
            Caller4147.Step3();
            Caller4147.Step4();
            Caller4147.Step5();
            Caller4147.Step6();
            Console.WriteLine();

            Console.WriteLine(1953);
            Caller1953.Step1();
            Caller1953.Step2();
            Caller1953.Step3();
            Caller1953.Step4();
            Console.WriteLine();

            Console.WriteLine(3956);
            Caller3956.Step1();
            Caller3956.Step2();
            Caller3956.Step3();
            Caller3956.Step4();
        }
    }
}
